#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <gui/elements.h>
#include <gui/view_dispatcher.h>
#include <gui/modules/submenu.h>
#include <gui/modules/text_box.h>
#include <gui/modules/widget.h>
#include <notification/notification_messages.h>
#include <lib/subghz/subghz_tx_rx_worker.h>
#include <storage/storage.h>

#define TAG "AutoSec"
#define LOG_FILE_PATH EXT_PATH("autosec_log.txt")
#define SIGNAL_STORAGE_PATH EXT_PATH("autosec_signals")

typedef enum {
    AutoSecViewSubmenu,
    AutoSecViewScanner,
    AutoSecViewAnalysis,
    AutoSecViewAbout,
} AutoSecView;

typedef enum {
    AutoSecSubmenuIndexScan,
    AutoSecSubmenuIndexAnalysis,
    AutoSecSubmenuIndexAbout,
} AutoSecSubmenuIndex;

typedef struct {
    uint32_t frequency;
    uint32_t rssi;
    uint32_t signal_count;
    uint32_t timestamp;
    char modulation[32];
} SignalData;

typedef struct {
    ViewDispatcher* view_dispatcher;
    Submenu* submenu;
    TextBox* text_box;
    Widget* widget;
    
    SubGhzTxRxWorker* subghz_worker;
    uint32_t frequency;
    bool is_scanning;
    uint32_t signal_count;
    SignalData last_signal;
} AutoSecApp;

// Forward declarations
static void autosec_app_draw_scanner(Canvas* canvas, AutoSecApp* app);
static void autosec_app_draw_analysis(Canvas* canvas, AutoSecApp* app);
static void autosec_app_draw_about(Canvas* canvas, AutoSecApp* app);

// Submenu callback
static void autosec_submenu_callback(void* context, uint32_t index) {
    AutoSecApp* app = (AutoSecApp*)context;
    
    switch(index) {
        case AutoSecSubmenuIndexScan:
            view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewScanner);
            app->is_scanning = true;
            break;
        case AutoSecSubmenuIndexAnalysis:
            view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewAnalysis);
            break;
        case AutoSecSubmenuIndexAbout:
            view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewAbout);
            break;
    }
}

// Scanner view callback
static void autosec_scanner_view_callback(Canvas* canvas, void* context) {
    AutoSecApp* app = (AutoSecApp*)context;
    autosec_app_draw_scanner(canvas, app);
}

// Analysis view callback
static void autosec_analysis_view_callback(Canvas* canvas, void* context) {
    AutoSecApp* app = (AutoSecApp*)context;
    autosec_app_draw_analysis(canvas, app);
}

// About view callback
static void autosec_about_view_callback(Canvas* canvas, void* context) {
    AutoSecApp* app = (AutoSecApp*)context;
    autosec_app_draw_about(canvas, app);
}

// Input callback for scanner
static void autosec_scanner_input_callback(InputEvent* event, void* context) {
    AutoSecApp* app = (AutoSecApp*)context;
    
    if(event->type == InputTypePress) {
        if(event->key == InputKeyBack) {
            app->is_scanning = false;
            view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewSubmenu);
        }
    }
}

// Input callback for analysis
static void autosec_analysis_input_callback(InputEvent* event, void* context) {
    AutoSecApp* app = (AutoSecApp*)context;
    
    if(event->type == InputTypePress) {
        if(event->key == InputKeyBack) {
            view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewSubmenu);
        }
    }
}

// Input callback for about
static void autosec_about_input_callback(InputEvent* event, void* context) {
    AutoSecApp* app = (AutoSecApp*)context;
    
    if(event->type == InputTypePress) {
        if(event->key == InputKeyBack) {
            view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewSubmenu);
        }
    }
}

// Draw scanner view
static void autosec_app_draw_scanner(Canvas* canvas, AutoSecApp* app) {
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 10, 15, "Sub-GHz Scanner");
    
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str_aligned(canvas, 64, 30, AlignCenter, AlignCenter, "433.92 MHz");
    
    if(app->is_scanning) {
        canvas_draw_str_aligned(canvas, 64, 50, AlignCenter, AlignCenter, "SCANNING...");
        canvas_draw_str_aligned(canvas, 64, 65, AlignCenter, AlignCenter, 
                               furi_string_get_cstr(furi_string_alloc_printf("Signals: %lu", app->signal_count)));
    } else {
        canvas_draw_str_aligned(canvas, 64, 50, AlignCenter, AlignCenter, "STOPPED");
    }
    
    canvas_draw_str_aligned(canvas, 64, 120, AlignCenter, AlignCenter, "Press BACK to exit");
}

// Draw analysis view
static void autosec_app_draw_analysis(Canvas* canvas, AutoSecApp* app) {
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 10, 15, "Signal Analysis");
    
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str_aligned(canvas, 64, 35, AlignCenter, AlignCenter, 
                           furi_string_get_cstr(furi_string_alloc_printf("Freq: %lu Hz", app->last_signal.frequency)));
    canvas_draw_str_aligned(canvas, 64, 50, AlignCenter, AlignCenter, 
                           furi_string_get_cstr(furi_string_alloc_printf("RSSI: %ld dBm", (int32_t)app->last_signal.rssi)));
    canvas_draw_str_aligned(canvas, 64, 65, AlignCenter, AlignCenter, 
                           furi_string_get_cstr(furi_string_alloc_printf("Total: %lu", app->signal_count)));
    
    canvas_draw_str_aligned(canvas, 64, 120, AlignCenter, AlignCenter, "Press BACK to exit");
}

// Draw about view
static void autosec_app_draw_about(Canvas* canvas, AutoSecApp* app) {
    UNUSED(app);
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 10, 15, "AutoSec Tool v1.0");
    
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 10, 35, "Automotive Security");
    canvas_draw_str(canvas, 10, 50, "Research Platform");
    
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 10, 70, "LEGAL NOTICE:");
    canvas_draw_str(canvas, 10, 85, "Authorized research only.");
    canvas_draw_str(canvas, 10, 100, "Unauthorized access is");
    canvas_draw_str(canvas, 10, 115, "illegal in most countries.");
    
    canvas_draw_str_aligned(canvas, 64, 120, AlignCenter, AlignCenter, "Press BACK to exit");
}

// Application allocation
static AutoSecApp* autosec_app_alloc(void) {
    AutoSecApp* app = malloc(sizeof(AutoSecApp));
    
    // Create view dispatcher
    app->view_dispatcher = view_dispatcher_alloc();
    
    // Create submenu
    app->submenu = submenu_alloc();
    submenu_add_item(app->submenu, "Scanner", AutoSecSubmenuIndexScan, autosec_submenu_callback, app);
    submenu_add_item(app->submenu, "Analysis", AutoSecSubmenuIndexAnalysis, autosec_submenu_callback, app);
    submenu_add_item(app->submenu, "About", AutoSecSubmenuIndexAbout, autosec_submenu_callback, app);
    
    // Create text box
    app->text_box = text_box_alloc();
    
    // Create widget for custom drawing
    app->widget = widget_alloc();
    
    // Initialize state
    app->frequency = 433920000; // 433.92 MHz
    app->is_scanning = false;
    app->signal_count = 0;
    memset(&app->last_signal, 0, sizeof(SignalData));
    
    // Register views
    view_dispatcher_add_view(app->view_dispatcher, AutoSecViewSubmenu, submenu_get_view(app->submenu));
    
    // Create custom views for scanner and analysis
    View* scanner_view = view_alloc();
    view_set_draw_callback(scanner_view, autosec_scanner_view_callback);
    view_set_input_callback(scanner_view, autosec_scanner_input_callback);
    view_set_context(scanner_view, app);
    view_dispatcher_add_view(app->view_dispatcher, AutoSecViewScanner, scanner_view);
    
    View* analysis_view = view_alloc();
    view_set_draw_callback(analysis_view, autosec_analysis_view_callback);
    view_set_input_callback(analysis_view, autosec_analysis_input_callback);
    view_set_context(analysis_view, app);
    view_dispatcher_add_view(app->view_dispatcher, AutoSecViewAnalysis, analysis_view);
    
    View* about_view = view_alloc();
    view_set_draw_callback(about_view, autosec_about_view_callback);
    view_set_input_callback(about_view, autosec_about_input_callback);
    view_set_context(about_view, app);
    view_dispatcher_add_view(app->view_dispatcher, AutoSecViewAbout, about_view);
    
    // Set initial view
    view_dispatcher_switch_to_view(app->view_dispatcher, AutoSecViewSubmenu);
    
    // Get GUI
    Gui* gui = furi_record_open(RECORD_GUI);
    view_dispatcher_attach_to_gui(app->view_dispatcher, gui);
    
    return app;
}

// Application deallocation
static void autosec_app_free(AutoSecApp* app) {
    view_dispatcher_remove_view(app->view_dispatcher, AutoSecViewSubmenu);
    view_dispatcher_remove_view(app->view_dispatcher, AutoSecViewScanner);
    view_dispatcher_remove_view(app->view_dispatcher, AutoSecViewAnalysis);
    view_dispatcher_remove_view(app->view_dispatcher, AutoSecViewAbout);
    
    submenu_free(app->submenu);
    text_box_free(app->text_box);
    widget_free(app->widget);
    view_dispatcher_free(app->view_dispatcher);
    furi_record_close(RECORD_GUI);
    free(app);
}

// Main application entry point
int32_t autosec_tool_app(void* p) {
    UNUSED(p);
    AutoSecApp* app = autosec_app_alloc();
    view_dispatcher_run(app->view_dispatcher);
    autosec_app_free(app);
    return 0;
}
